package br.com.nexustech.main;

import br.com.nexustech.exception.BanidoException;
import br.com.nexustech.exception.NivelInsuficienteException;
import br.com.nexustech.model.Masmorra;
import br.com.nexustech.model.Matchmaker;
import br.com.nexustech.model.ModoCasual;
import br.com.nexustech.model.ModoRanqueado;

public class Main {

    public static void main(String[] args) {

        // EXERCÍCIO 1 e 2 - Divisão por zero

        int kills = 15;
        int deaths = 0;

        try {

            System.out.println(kills / deaths);

        } catch (ArithmeticException e) {

            System.out.println("Taxa K/D: Jogador Invicto!");
        }


        // EXERCÍCIO 3 - Inventário

        String[] inventario = new String[3];

        try {

            inventario[5] = "Espada";

        } catch (ArrayIndexOutOfBoundsException e) {

            System.out.println("Inventário cheio!");
        }


        // EXERCÍCIO 4 - NullPointer

        String jogador = null;

        if (jogador != null) {

            System.out.println(jogador);

        } else {

            System.out.println("Jogador desconectado");
        }


        // EXERCÍCIOS 5, 6 e 7 - Servidor

        try {

            conectarServidor();

        } catch (Exception e) {

            System.out.println(e.getMessage());

        } finally {

            System.out.println(
                    "Fechando portas de rede do jogo..."
            );
        }


        // EXERCÍCIOS 8 e 9 - Masmorra

        Masmorra masmorra = new Masmorra();

        try {

            masmorra.entrar(20);

        } catch (NivelInsuficienteException e) {

            System.out.println(e.getMessage());
        }


        // EXERCÍCIOS 10 a 14 - Matchmaker

        Matchmaker matchmaker = new Matchmaker();

        ModoCasual casual = new ModoCasual();
        ModoRanqueado ranqueado = new ModoRanqueado();

        try {

            // Teste normal
            matchmaker.encontrarSala(casual, false);

            matchmaker.encontrarSala(ranqueado, false);

            // Jogador banido
            matchmaker.encontrarSala(casual, true);

        } catch (BanidoException e) {

            System.out.println(e.getMessage());
        }
    }


    // EXERCÍCIO 5 - Método fora do main

    public static void conectarServidor() throws Exception {

        throw new Exception("Servidor caiu!");
    }
}