package br.com.technexus.main;

import br.com.technexus.model.Loja;
import br.com.technexus.model.Produto;

public class Main {

    public static void main(String[] args) {

        // Criando a loja
        Loja loja = new Loja();


        // Cadastrando 2 GAMES
        loja.cadastrar(
                new Produto("The Witcher", "GAMES", 150.00)
        );

        loja.cadastrar(
                new Produto("FIFA", "GAMES", 200.00)
        );


        // Cadastrando 2 LIVROS
        loja.cadastrar(
                new Produto("Java for Dummies", "LIVROS", 100.00)
        );

        loja.cadastrar(
                new Produto("Clean Code", "LIVROS", 80.00)
        );


        // Cadastrando 1 HARDWARE
        loja.cadastrar(
                new Produto("Mouse", "HARDWARE", 50.00)
        );


        // TESTE 1 - Buscar apenas GAMES
        System.out.println("=== GAMES ===");

        System.out.println(
                loja.buscarPorCategoria("GAMES")
        );


        // TESTE 2 - Patrimônio total
        System.out.println("\n=== PATRIMÔNIO TOTAL ===");

        System.out.println(
                "R$ " + loja.calcularPatrimonioTotal()
        );


        // TESTE 3 - Total apenas dos LIVROS
        System.out.println("\n=== TOTAL DOS LIVROS ===");

        System.out.println(
                "R$ " + loja.calcularTotalPorCategoria("LIVROS")
        );
    }
}