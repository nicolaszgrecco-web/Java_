package br.com.techcorp.main;

import br.com.techcorp.model.ControleDeAcesso;
import br.com.techcorp.model.Funcionario;

public class MainTechCorp {

    public static void main(String[] args) {

        // Criando o controle de acesso
        ControleDeAcesso controle = new ControleDeAcesso();

        // Funcionário original
        Funcionario f1 = new Funcionario(
                "T-001",
                "Alice",
                "Desenvolvedora"
        );

        // Funcionário duplicado
        Funcionario f2 = new Funcionario(
                "T-001",
                "Alice Duplicada",
                "Desenvolvedora"
        );

        // TESTE DA CATRACA
        controle.registrarPassagem(f1);
        controle.registrarPassagem(f2);

        // TESTE DA SALA SEGURA
        controle.concederAcessoSala(f1);
        controle.concederAcessoSala(f2);
    }
}